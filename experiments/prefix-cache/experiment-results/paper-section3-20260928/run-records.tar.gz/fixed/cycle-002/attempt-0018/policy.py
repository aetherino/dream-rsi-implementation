class CachePolicy:
    def __init__(self):
        self._last = {}
        self._freq = {}
        self._ins = {}
        self._depth = {}
        self._order = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self._last[b] = entry.last_access
        self._freq[b] = entry.frequency
        self._ins[b] = entry.inserted_at
        self._depth[b] = entry.depth
        self._order[b] = entry.access_order

    def observe_hit(self, entry):
        b = entry.block_id
        self._last[b] = entry.last_access
        self._freq[b] = entry.frequency
        self._order[b] = entry.access_order

    def observe_evict(self, entry):
        self._last.pop(entry.block_id, None)
        self._freq.pop(entry.block_id, None)
        self._ins.pop(entry.block_id, None)
        self._depth.pop(entry.block_id, None)
        self._order.pop(entry.block_id, None)

    def choose(self, eligible, now):
        a = eligible[0]
        ka = (a.last_access, a.access_order, a.insertion_order, a.depth)
        for e in eligible[1:]:
            k = (e.last_access, e.access_order, e.insertion_order, e.depth)
            if k < ka:
                ka = k
                a = e
        if a.frequency <= 1:
            return a.block_id
        b = None
        kb = None
        for e in eligible:
            if e.block_id == a.block_id:
                continue
            if e.frequency > 1:
                continue
            k = (e.last_access, e.access_order, e.insertion_order, e.depth)
            if kb is None or k < kb:
                kb = k
                b = e
        if b is not None:
            pa = self._depth.get(a.block_id, a.depth)
            pb = self._depth.get(b.block_id, b.depth)
            if pb >= pa:
                return b.block_id
        return a.block_id
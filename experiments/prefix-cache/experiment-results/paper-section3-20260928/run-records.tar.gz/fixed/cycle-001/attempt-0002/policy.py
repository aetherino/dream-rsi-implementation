class CachePolicy:
    def __init__(self):
        self._live = {}
        self._detached = {}
        self._decision_count = 0

    def observe_insert(self, entry):
        self._live[entry.block_id] = entry

    def observe_hit(self, entry):
        self._live[entry.block_id] = entry

    def observe_evict(self, entry):
        self._detached.pop(entry.block_id, None)
        self._live.pop(entry.block_id, None)
        self._detached[entry.block_id] = entry
        if len(self._detached) > 8192:
            self._detached.pop(next(iter(self._detached)), None)

    def choose(self, eligible, now):
        self._decision_count += 1
        for entry in eligible:
            self._live[entry.block_id] = entry
        best = None
        best_key = None
        for entry in eligible:
            observed = self._live.get(entry.block_id, entry)
            frequency = max(entry.frequency, getattr(observed, 'frequency', 0))
            if entry.block_id in self._detached:
                # The entry returned after an eviction without a fresh insert event.
                # Treat it as its original cache age rather than making it brand new.
                inserted_at = self._detached[entry.block_id].inserted_at
            else:
                inserted_at = entry.inserted_at
            age = 1.0 + max(0.0, now - inserted_at)
            idle = 1.0 + max(0.0, now - entry.last_access)
            priority = (frequency + 1.0) * (age ** 0.12) / (idle ** 0.78)
            key = (priority, entry.access_order, entry.block_id)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

class CachePolicy:
    def __init__(self):
        self._freq = {}
        self._last_touch = {}
        self._task = {}
        self._task_ts = {}
        self._evicted = {}
        self._decisions = 0
        self._idles = []

    def observe_insert(self, entry):
        bid = entry.block_id
        self._freq[bid] = entry.frequency
        self._last_touch[bid] = entry.last_access
        t = getattr(entry, "task_chat", None)
        if t is None:
            t = getattr(entry, "task_unknown", 0)
        self._task[bid] = t
        self._task_ts[bid] = entry.last_access

    def observe_hit(self, entry):
        bid = entry.block_id
        self._freq[bid] = entry.frequency
        self._last_touch[bid] = entry.last_access
        t = getattr(entry, "task_chat", None)
        if t is None:
            t = getattr(entry, "task_unknown", 0)
        self._task[bid] = t
        self._task_ts[bid] = entry.last_access

    def observe_evict(self, entry):
        bid = entry.block_id
        self._evicted[bid] = entry.last_access
        self._freq.pop(bid, None)
        self._last_touch.pop(bid, None)
        self._task.pop(bid, None)
        self._task_ts.pop(bid, None)

    def choose(self, eligible, now):
        self._decisions += 1
        live_ids = set()
        for e in eligible:
            bid = e.block_id
            live_ids.add(bid)
            f = self._freq.get(bid)
            if f is None or f < e.frequency:
                self._freq[bid] = e.frequency
            lt = self._last_touch.get(bid)
            if lt is None or lt < e.last_access:
                self._last_touch[bid] = e.last_access
        for bid in list(self._evicted.keys()):
            if bid in live_ids:
                self._evicted.pop(bid, None)

        idles = []
        for e in eligible:
            v = self._last_touch.get(e.block_id)
            if v is None:
                v = e.last_access
            d = now - v
            if d < 0:
                d = 0
            idles.append(d)
        idles.sort()
        n = len(idles)
        if n <= 20:
            med = idles[n // 2]
        else:
            med = idles[int(n * 0.5)]
        gap = med - idles[0] if med > idles[0] else 1
        thr = idles[0] + gap * 0.6

        best = None
        best_score = None
        for e in eligible:
            bid = e.block_id
            v = self._last_touch.get(bid)
            if v is None:
                v = e.last_access
            d = now - v
            if d < 0:
                d = 0
            last = self._evicted.get(bid)
            if last is not None and (now - last) <= 2:
                score = -1e12
            elif d <= thr:
                f = self._freq.get(bid, e.frequency)
                if f is None:
                    f = 1
                ti = self._task.get(bid)
                if ti is None:
                    ti = 1
                score = f + 3 * ti
            else:
                score = 1000000000 + d
            if best_score is None or score < best_score:
                best_score = score
                best = e
        self._evicted[best.block_id] = now
        return best.block_id

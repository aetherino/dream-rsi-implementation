class CachePolicy:
    def choose(self, eligible, now):
        def key(e):
            freq = e.frequency
            rec = 1.0 / (1 + (now - e.last_access))
            return (freq, rec)
        best = eligible[0]
        best_key = key(best)
        for e in eligible[1:]:
            k = key(e)
            if k < best_key:
                best, best_key = e, k
        return best.block_id

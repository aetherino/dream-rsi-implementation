class CachePolicy:
    def __init__(self):
        self._hits = {}
        self._last = {}
        self._freq = {}

    def observe_insert(self, entry):
        bid = entry.block_id
        self._last[bid] = entry.last_access
        self._freq[bid] = entry.frequency
        if bid not in self._hits:
            self._hits[bid] = 0.0

    def observe_hit(self, entry):
        bid = entry.block_id
        pl = self._last.get(bid)
        pf = self._freq.get(bid)
        gap = 0.0
        if pl is not None:
            gap = float(entry.last_access) - float(pl)
            if gap < 0.0:
                gap = 0.0
        df = 1
        if pf is not None:
            df = entry.frequency - pf
            if df < 1:
                df = 1
        self._last[bid] = entry.last_access
        self._freq[bid] = entry.frequency
        v = self._hits.get(bid, 0.0)
        if v < 2.0:
            v += 1.0 / float(df)
            if v > 2.0:
                v = 2.0
            self._hits[bid] = v

    def observe_evict(self, entry):
        bid = entry.block_id
        self._hits.pop(bid, None)
        self._last.pop(bid, None)
        self._freq.pop(bid, None)

    def choose(self, eligible, now):
        best = None
        best_key = None
        best_adj = None
        for e in eligible:
            idle = 1.0 + max(0.0, float(now) - float(e.last_access))
            bonus = self._hits.get(e.block_id, 0.0)
            if getattr(e, 'task_qa', False) and e.turn_index == 0:
                bonus += 0.10
            adj = idle * (1.0 - 0.01 * bonus)
            key = (e.last_access, e.access_order, e.insertion_order, e.depth, adj)
            if best_key is None or key < best_key:
                best_key = key
                best = e
                best_adj = adj
        return best.block_id
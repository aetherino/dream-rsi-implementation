class CachePolicy:
    def __init__(self):
        self._prot = {}
        self._turn = {}
        self._maxturn = {}
        self._last_hit_order = {}
        self._kind = {}
        self._ao = 0

    def observe_insert(self, entry):
        self._prot[entry.block_id] = 0.0
        self._turn[entry.block_id] = entry.turn_index
        prev = self._maxturn.get(entry.block_id, -1)
        self._maxturn[entry.block_id] = entry.turn_index if entry.turn_index > prev else prev
        self._last_hit_order[entry.block_id] = entry.access_order
        self._kind[entry.block_id] = self._k(entry)
        self._ao = entry.access_order

    def observe_hit(self, entry):
        self._ao = entry.access_order
        self._turn[entry.block_id] = entry.turn_index
        prev = self._maxturn.get(entry.block_id, -1)
        self._maxturn[entry.block_id] = entry.turn_index if entry.turn_index > prev else prev
        old_order = self._last_hit_order.get(entry.block_id)
        self._last_hit_order[entry.block_id] = entry.access_order
        if old_order is None or entry.access_order > old_order:
            k = self._k(entry)
            if k == 'qa':
                d = 0.45
            elif k == 'chat':
                d = 0.12
            elif k == 'unknown':
                d = 0.05
            else:
                d = -0.30
            self._prot[entry.block_id] = min(40.0, self._prot.get(entry.block_id, 0.0) + d)
        self._kind[entry.block_id] = self._k(entry)

    def observe_evict(self, entry):
        self._prot.pop(entry.block_id, None)
        self._kind.pop(entry.block_id, None)

    @staticmethod
    def _k(entry):
        if getattr(entry, 'task_qa', False):
            return 'qa'
        if getattr(entry, 'task_chat', False):
            return 'chat'
        if getattr(entry, 'task_unknown', False):
            return 'unknown'
        return 'other'

    def choose(self, eligible, now):
        best = None
        best_key = None
        for e in eligible:
            idle = 1.0 + max(0.0, now - e.last_access)
            p = self._prot.get(e.block_id, 0.0)
            mt = self._maxturn.get(e.block_id, -1)
            ti = self._turn.get(e.block_id, e.turn_index)
            grow = (mt >= 3 and ti == mt)
            k = self._kind.get(e.block_id, self._k(e))
            if k == 'qa':
                d = 0.45
            elif k == 'chat':
                d = 0.12
            elif k == 'unknown':
                d = 0.05
            else:
                d = -0.30
            if grow and k in ('qa', 'chat'):
                p = min(40.0, p + d)
            if grow:
                adj = idle * 0.62
            elif p > 0.05:
                adj = idle * (1.0 + p)
            else:
                adj = idle
            key = (adj, e.access_order, e.insertion_order, e.depth, e.block_id)
            if best_key is None or key < best_key:
                best_key = key
                best = e
        return best.block_id

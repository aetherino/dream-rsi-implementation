class CachePolicy:
    def __init__(self):
        self._prev_last = {}
        self._prev_freq = {}
        self._qa_hits = {}

    def observe_insert(self, entry):
        bid = entry.block_id
        self._prev_last[bid] = entry.last_access
        self._prev_freq[bid] = entry.frequency

    def observe_hit(self, entry):
        bid = entry.block_id
        pl = self._prev_last.get(bid)
        pf = self._prev_freq.get(bid)
        gap = 0.0
        if pl is not None:
            gap = float(entry.last_access) - float(pl)
            if gap < 0.0:
                gap = 0.0
        df = 1
        if pf is not None:
            df = entry.frequency - pf
            if df < 1:
                df = 1
        self._prev_last[bid] = entry.last_access
        self._prev_freq[bid] = entry.frequency
        if getattr(entry, 'task_qa', False):
            v = self._qa_hits.get(bid, 0.0)
            if v < 4.0:
                v += 1.0 / float(df)
                if v > 4.0:
                    v = 4.0
                self._qa_hits[bid] = v

    def observe_evict(self, entry):
        bid = entry.block_id
        self._qa_hits.pop(bid, None)
        self._prev_last.pop(bid, None)
        self._prev_freq.pop(bid, None)

    def choose(self, eligible, now):
        best = None
        best_key = None
        for e in eligible:
            idle = 1.0 + max(0.0, float(now) - float(e.last_access))
            bonus = self._qa_hits.get(e.block_id, 0.0)
            if getattr(e, 'task_qa', False) and e.turn_index == 0:
                bonus += 0.25
            adj = idle * (1.0 - 0.03 * bonus)
            key = (adj, e.access_order, e.insertion_order, e.block_id)
            if best_key is None or key < best_key:
                best_key = key
                best = e
        return best.block_id

class CachePolicy:
    def __init__(self):
        self.last_seen = {}

    def choose(self, eligible, now):
        # Pick the entry that looks least likely to be reused soon:
        # small frequency, old last access, and not recently inserted.
        def score(e):
            freq = e.frequency
            recency = 1.0 / (1.0 + (now - e.last_access))
            insert_recency = 1.0 / (1.0 + (now - e.inserted_at))
            # Weight frequency a bit, but not so strongly that a
            # single hit protects a block forever (LFU over-protected
            # hot-looking prefixes). Recency dominates.
            return recency + 0.15 * insert_recency + 0.05 * freq

        best = eligible[0]
        best_s = score(best)
        for e in eligible[1:]:
            s = score(e)
            if s < best_s:
                best, best_s = e, s
        self.last_seen[best.block_id] = now
        return best.block_id

    def observe_insert(self, entry):
        self.last_seen[entry.block_id] = entry.inserted_at

    def observe_hit(self, entry):
        self.last_seen[entry.block_id] = entry.last_access

    def observe_evict(self, entry):
        self.last_seen.pop(entry.block_id, None)

class CachePolicy:
    def choose(self, eligible, now):
        best = None
        best_key = None
        for e in eligible:
            key = (e.last_access, e.access_order, e.insertion_order, e.depth)
            if best_key is None or key < best_key:
                best_key = key
                best = e
        return best.block_id
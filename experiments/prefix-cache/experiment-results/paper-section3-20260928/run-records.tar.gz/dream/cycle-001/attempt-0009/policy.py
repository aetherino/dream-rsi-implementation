class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.evictions = {}
        self.inserted = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Measured evidence through id 7: exact LRU and strict tie-break
        # variants score 0.0, while the only large departure (id 1,
        # frequency/recency multiplier) scores -1.34, inflating suite extra
        # tokens from 132,144 to 309,856.  The first measured positive result
        # (id 7) is a strictly bounded depth bonus (8/16 virtual-time units)
        # applied to near-LRU candidates: score 0.0006054, saving 80 suite
        # tokens overall with small wins on chat-heavy-00/01, balanced-01,
        # qa-heavy-00/01 and only a small regression on balanced-00.  The
        # structural hypothesis behind that gain is confirmed directionally:
        # among near-LRU candidates, evicting a deeper chain tail first frees
        # a block and can expose its next ancestor as eligible later, while
        # evicting a shallow leaf strands a resident chain behind it and costs
        # many recomputed tokens if that chain is reused.
        #
        # Revised hypothesis (v2): keep the same bounded-greedy shape but
        # scale the depth bonus with observed reuse, since a chain that has
        # already been hit is more likely to be visited again and therefore
        # more worth protecting at its shallow end.  The bonus is still
        # strictly bounded (<= 32 virtual-time units) so a materially older
        # block is still evicted first and the policy cannot reproduce the
        # id-1 catastrophe.  Bonus = 8 (depth>=1) + 8 (depth>=2) + 8 (hits>0,
        # depth>=1) + 8 (hits>0, depth>=2), i.e. at most 32, giving extra
        # protection to frequently-hit deep tails relative to one-shot tails
        # while keeping the primary ordering near-LRU.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            hits = self.hits.get(b, 0)
            bonus = 0
            if depth >= 1:
                bonus += 8
            if depth >= 2:
                bonus += 8
            if hits > 0:
                if depth >= 1:
                    bonus += 8
                if depth >= 2:
                    bonus += 8
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

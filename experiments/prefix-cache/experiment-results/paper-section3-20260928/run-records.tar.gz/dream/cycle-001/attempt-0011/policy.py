class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.evictions = {}
        self.inserted = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Complete measured feedback through id 9:
        #   id 0 and strict-LRU-tie variants (2,3,5,6): 0.0
        #   id 1 (unbounded frequency/recency multiplier): -1.34 (catastrophic)
        #   id 7 (bounded depth bonus 8/16, depth>=1/2): +0.0006054
        #   id 8 (identical to id 7 shape): +0.0006054 (duplicate, same result)
        #   id 9 (bounded depth bonus + extra hit-based tiers, cap 32): +0.0003632
        # The selected parent (id 7) is the current best measured result.
        # Id 9 shows that adding hit-based extra protection (cap 32) HURT
        # relative to id 7 (0.0003632 < 0.0006054), losing on balanced-00
        # and chat-heavy-00 while gaining less elsewhere; therefore the hit
        # term is revised out of the ranking key.
        #
        # Revised hypothesis (v3): retain the measured-winning bounded depth
        # bonus exactly as id 7 used it (8 for depth>=1, 16 for depth>=2), and
        # explore only a strictly bounded, monotonic continuation of that
        # already-validated shape: give a small extra bonus to very deep tails
        # (depth>=3) since the measured positive result came from preferring
        # deeper chain tails and the next logical refinement is to strengthen
        # that preference for the deepest tails while keeping the total bonus
        # bounded so a materially older block is still evicted first.
        # The bonus stays <= 24 virtual-time units, preventing any replay of
        # the id-1 catastrophe where large recency overrides destroyed reuse.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            else:
                bonus = 24
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

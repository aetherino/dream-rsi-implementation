class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Measured evidence through id 13 is authoritative:
        #   id 0 and strict-LRU-tie variants (2,3,5,6): 0.0
        #   id 1 (unbounded frequency/recency multiplier): -1.34 (catastrophic)
        #   id 7/8 (bounded depth bonus 8/16): +0.0006054 (80 tokens saved)
        #   id 9 (depth bonus plus hit tiers, cap 32): +0.0003632 (worse)
        #   id 10/11 (8/16/24): +0.0021794 (288 tokens saved)
        #   id 12/13 (8/16/24/32): +0.0055697 (736 tokens saved)
        # The depth-bonus series is monotonically improving as the deepest
        # tier grows: 16 -> +80, 24 -> +288, 32 -> +736 saved suite tokens.
        #
        # Revised hypothesis (v5): continue that validated monotone direction
        # with the smallest remaining step: keep 8/16/24 for depth 1/2/3 and
        # raise the depth>=4 bonus from 32 to 40, hard-capped at 40 virtual-
        # time units so any block more than 40 time units older is still
        # evicted first regardless of depth. This preserves the near-LRU
        # property shared by every measured positive result and absent from
        # the id-1 catastrophe, while further strengthening the structural
        # tail-first effect. Id 9 keeps frequency excluded from the key.
        # Task flags remain unused (category does not guarantee reuse).
        # block_id is only a deterministic identity tie-break.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            elif depth == 3:
                bonus = 24
            else:
                bonus = 40
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

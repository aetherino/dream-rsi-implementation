class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Complete measured feedback is authoritative:
        #   id 0 and strict-LRU-tie variants (2,3,5,6): 0.0
        #   id 1 (unbounded frequency/recency multiplier): -1.34 (catastrophic)
        #   id 7/8 (bounded depth bonus 8/16): +0.0006054 (80 tokens saved)
        #   id 9 (depth bonus plus hit tiers, cap 32): +0.0003632 (worse)
        #   id 10/11 (8/16/24): +0.0021794 (288 tokens saved)
        #   id 12/13 (8/16/24/32): +0.0055697 (736 tokens saved)
        #   id 14 (8/16/24/40 for depth>=4, cap 40): +0.0072648 (960 saved)
        #   id 15 (8/16/24/32/40, cap 40): +0.0090810 (1200 saved)
        #   id 16/17 (8/16/24/32/40/48, cap 48): +0.0140453 (1856 saved)
        #   id 18/19 (8/16/24/32/40/48/56, cap 56): +0.0202204 (2672 saved)
        # The depth-bonus series is monotonically improving as the graduated
        # schedule grows finer and the cap grows: 8/16 -> 80, 8/16/24 -> 288,
        # 8/16/24/32 -> 736, 8/16/24/32/40 -> 1200, 8/16/24/32/40/48 -> 1856,
        # 8/16/24/32/40/48/56 -> 2672 suite tokens saved. Ids 18 and 19 are
        # functionally identical duplicates, both measured at +0.0202204.
        #
        # Revised hypothesis (v8): continue that validated monotone direction
        # with the smallest remaining step: add one more graduated tier, 64 for
        # depth>=8, still hard-capped at 64 virtual-time units so any block more
        # than 64 time units older is evicted first regardless of depth. This
        # preserves the near-LRU property shared by every measured positive
        # result and absent from the id-1 catastrophe, while further
        # strengthening the structural tail-first effect. Id 9 keeps frequency
        # excluded from the key. Task flags remain unused (category does not
        # guarantee reuse). block_id is only a deterministic identity tie-break.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            elif depth == 3:
                bonus = 24
            elif depth == 4:
                bonus = 32
            elif depth == 5:
                bonus = 40
            elif depth == 6:
                bonus = 48
            elif depth == 7:
                bonus = 56
            else:
                bonus = 64
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.evictions = {}
        self.inserted = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Measured evidence so far: exact LRU and every strictly-LRU-tie
        # variant score 0.0, while the one large departure (id 1,
        # frequency/recency multiplier) scored -1.34.  The target is total
        # recomputed tokens, so a good policy must keep the useful hot prefix
        # resident and evict cold chain tails.  Hypothesis: among near-LRU
        # candidates, preferring the deepest tail is a bounded, structural
        # signal -- evicting a tail immediately frees one block and may expose
        # its parent as eligible later, while evicting a shallow leaf would
        # strand a long resident chain and cost many recomputed tokens if it
        # is ever reused.  The depth bonus is deliberately small (<= 16
        # virtual-time units) so a clearly older block is still evicted first;
        # this keeps the policy near the verified LRU baseline on the large
        # scenario suite while exploring the one structural direction left
        # untested by the completed measured runs.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            bonus = 16 if depth >= 2 else (8 if depth == 1 else 0)
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

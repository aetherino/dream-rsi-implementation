class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)

    def choose(self, eligible, now):
        # Measurement is authoritative: the frequency/recency multiplier
        # (id 1) scored -1.34 while exact LRU and two conservative LRU-derived
        # variants (ids 2, 3) both measured 0.0. Aggressive non-LRU weighting
        # therefore costs far more than it saves on this suite, especially on
        # chat-heavy and shift workloads where LRU itself already does well.
        #
        # Revised hypothesis: stay inside the measured LRU equivalence class
        # and change only exact ties. Among blocks with identical last_access
        # and access_order, prefer to evict the deeper chain tail first, since
        # evicting a tail lets its next ancestor become eligible later and
        # avoids stranding a resident chain behind an unusable prefix. If depth
        # also ties, prefer the older insertion and then the lower observed hit
        # count as a weak tie-break, since a block with more observed reuse is
        # marginally more likely to be reused again. The final key uses
        # block_id only as a deterministic identity handle for total ordering,
        # never as a predictive feature, so every choice is reproducible.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            hits = self.hits.get(b, 0)
            key = (
                last,
                entry.access_order,
                -depth,
                entry.insertion_order,
                hits,
                b,
            )
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.evictions = {}
        self.first_evict = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.first_evict.setdefault(b, 0)
        self.first_evict[b] += 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)

    def choose(self, eligible, now):
        # Measurement is authoritative: exact LRU ordering (and every variant
        # whose primary key is (last_access, access_order)) measured 0.0 on the
        # full suite, while the frequency/recency multiplier measured -1.34 and
        # inflated suite extra tokens from 132,144 to 309,856.  Therefore the
        # primary eviction decision remains pure recency: evict the entry with
        # the smallest (last_access, access_order).
        #
        # The only remaining freedom is how to break exact recency ties, which
        # by definition never cost a recency decision.  Revised hypothesis:
        # among entries with identical last_access and access_order, first
        # prefer entries that have never been observed to be reused (hits == 0)
        # over entries with observed reuse, because a block that has already
        # been touched again is a better candidate for another future touch.
        # Second, among equally-reused entries, prefer the deeper chain tail,
        # since evicting a tail permits its next ancestor to become eligible
        # later and avoids stranding a resident chain behind an unusable
        # prefix.  Finally break ties deterministically by insertion_order and
        # block_id; block_id is used only as an identity handle for total
        # ordering and never as a predictive feature.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            hits = self.hits.get(b, 0)
            key = (
                last,
                entry.access_order,
                1 if hits > 0 else 0,
                -depth,
                entry.insertion_order,
                b,
            )
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

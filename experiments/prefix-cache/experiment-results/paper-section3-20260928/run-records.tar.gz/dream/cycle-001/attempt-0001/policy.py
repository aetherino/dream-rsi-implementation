class CachePolicy:
    def __init__(self):
        self.last = {}
        self.start = {}
        self.n = {}
        self.depth = {}
        self.inserted = {}
        self.evicted = {}

    def observe_insert(self, entry):
        bid = entry.block_id
        self.last[bid] = entry.last_access
        self.start.setdefault(bid, entry.inserted_at)
        self.n.setdefault(bid, 0)
        self.depth[bid] = entry.depth
        self.inserted[bid] = entry.inserted_at

    def observe_hit(self, entry):
        bid = entry.block_id
        self.last[bid] = entry.last_access
        self.start.setdefault(bid, entry.inserted_at)
        self.n[bid] = self.n.get(bid, 0) + 1
        self.depth[bid] = entry.depth

    def observe_evict(self, entry):
        bid = entry.block_id
        self.evicted[bid] = (self.evicted.get(bid, 0) + 1)

    def choose(self, eligible, now):
        best = None
        best_key = None
        for entry in eligible:
            bid = entry.block_id
            last = self.last.get(bid, entry.last_access)
            n = self.n.get(bid, 0)
            p = entry.depth
            try:
                a = self.inserted.get(bid, entry.inserted_at)
                width = 1.0 + (last - a) / 32000.0
            except Exception:
                width = 1.0
            f = n / width
            rec = (now - last) + (now - last) / (1.0 + n)
            val = f * rec
            key = (val, -p, entry.access_order, entry.insertion_order, bid)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

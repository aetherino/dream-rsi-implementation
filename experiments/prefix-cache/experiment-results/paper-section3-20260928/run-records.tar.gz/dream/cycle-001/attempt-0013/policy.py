class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Measured evidence is authoritative. Exact LRU and all strict LRU
        # tie-break variants score exactly 0.0. The unbounded frequency/recency
        # multiplier (id 1) scored -1.34 and is decisively rejected. The bounded
        # depth bonus with schedule 8/16 (id 7 and its functional clone id 8)
        # scored +0.000605. The hit-augmented variant (id 9, bonus up to 32)
        # scored lower at +0.000363, so observed frequency is not a useful bonus
        # term. The schedule 8/16/24 (ids 10 and 11, functionally identical)
        # is the best measured result at +0.002179, saving 288 suite tokens
        # (131,856 vs 132,144), with improvements on chat-heavy-00-cap2048
        # (-144), chat-heavy-01-cap2048 (-112), balanced-01-cap2048 (-96),
        # qa-heavy-00-cap2048 (-128) and qa-heavy-01-cap2048 (-80), partly offset
        # by regressions on balanced-00-cap2048 (+208), chat-heavy-01-cap4096
        # (+32) and shift-00-cap2048 (+32).
        #
        # Revised hypothesis (v4): the measured series shows a monotone gain
        # from increasing the depth bonus tier -- 8/16 gives +80 saved tokens,
        # 8/16/24 gives +288 -- while the cap remains small enough that a
        # materially older block is still evicted first. The next strictly
        # bounded continuation of that validated direction is a graduated
        # schedule: 8 for depth 1, 16 for depth 2, 24 for depth 3, and 32 for
        # depth >= 4, still hard-capped at 32 virtual-time units. Deeper leaves
        # are true chain tails: evicting one frees a block and exposes its next
        # ancestor as eligible later, while a shallow leaf anchors a longer
        # resident chain whose recomputation is expensive. The id-1 failure
        # came from overriding recency by orders of magnitude; a 32-unit cap
        # keeps this policy near-LRU and cannot reproduce that failure mode.
        # The id-9 result means frequency is excluded from the bonus. This is a
        # small monotone extrapolation of the only measured positive region and
        # may regress; if so, the exact 8/16/24 parameterization of ids 10/11 is
        # the validated fallback at +0.002179. Task flags remain unused because
        # the prompt states they do not guarantee future reuse and no completed
        # measurement supports task-aware weighting; block_id is used only as a
        # deterministic identity tie-break, never as a predictive feature.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            elif depth == 3:
                bonus = 24
            else:
                bonus = 32
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

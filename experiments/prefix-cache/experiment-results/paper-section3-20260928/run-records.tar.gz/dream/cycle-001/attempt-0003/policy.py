class CachePolicy:
    def __init__(self):
        self.last = {}
        self.first = {}
        self.count = {}
        self.evictions = {}
        self.seen = set()

    def observe_insert(self, entry):
        b = entry.block_id
        self.seen.add(b)
        self.last[b] = entry.last_access
        self.first.setdefault(b, entry.inserted_at)
        self.count[b] = self.count.get(b, 0) + 1

    def observe_hit(self, entry):
        b = entry.block_id
        self.seen.add(b)
        self.last[b] = entry.last_access
        self.first.setdefault(b, entry.inserted_at)
        self.count[b] = self.count.get(b, 0) + 1

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.first.pop(b, None)
        self.count.pop(b, None)
        self.seen.discard(b)

    def choose(self, eligible, now):
        # Conservative LRU with a depth tie-break: depth is only a tie-break,
        # so it cannot cause the catastrophic regressions seen in the prior
        # (unbounded depth-weighted) attempt. Preferring deeper leaves on
        # ties keeps evictions on chain tails so ancestors can become
        # eligible later without changing the primary recency ordering.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            # Primary key is recency; depth breaks ties toward deeper leaves.
            key = (last, -entry.depth, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

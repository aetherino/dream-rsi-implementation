class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Measured evidence is authoritative. Exact LRU and all strict LRU
        # tie-break variants score exactly 0.0. The unbounded frequency/recency
        # multiplier (id 1) scored -1.34 and is decisively rejected. The bounded
        # depth bonus family is the only measured positive region:
        #   schedule 8/16 (ids 7, 8):     +0.0006054  (80 tokens saved)
        #   schedule 8/16 + hit tiers
        #   (id 9, cap 32):               +0.0003632  (frequency hurts)
        #   schedule 8/16/24 (ids 10, 11): +0.0021794  (288 tokens saved)
        #   schedule 8/16/24/32 (ids 12, 13, graduated): +0.0055697
        #                                          (736 tokens saved)
        # The selected parent (id 13) is the current best measured result,
        # saving 736 suite tokens (131,408 vs LRU 132,144).  The measured
        # series shows a monotone improvement from strengthening the depth
        # bonus: 8/16 saves 80, 8/16/24 saves 288, 8/16/24/32 saves 736.
        # Id 9 proved that adding observed-hit terms to the bonus hurts, so
        # frequency is excluded from the ranking key.
        #
        # Revised hypothesis (v5): retain the verified best shape exactly (8
        # for depth 1, 16 for depth 2, 24 for depth 3, 32 for depth>=4) and
        # explore the next small, monotonic extension in the same confirmed
        # direction: add one more graduated tier, 40 for depth>=5, still
        # hard-capped at 40 virtual-time units so any block more than 40 time
        # units older is evicted first regardless of depth.  This preserves the
        # near-LRU property that separates every measured positive result from
        # the id-1 catastrophe, while slightly strengthening the structural
        # tail-first effect: a deep leaf is a true chain tail whose eviction
        # frees a block and exposes its next ancestor as eligible later,
        # whereas a shallow leaf anchors a longer resident chain whose
        # recomputation is expensive.  The progression 8 -> 16 -> 24 -> 32 ->
        # 40 is the smallest monotonic continuation of the validated
        # 8/16/24/32 schedule; if measurement regresses, restoring exactly id
        # 13's parameterization (8/16/24/32) is the validated fallback at
        # +0.0055697, and exact LRU remains the measured 0.0 safety net.
        #
        # Task flags (task_chat, task_qa, task_unknown, turn_index) remain
        # excluded: the prompt states task category does not guarantee future
        # reuse and no completed measurement supports task-aware weighting.
        # block_id is used only as a deterministic identity tie-break, never as
        # a predictive feature.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            elif depth == 3:
                bonus = 24
            elif depth == 4:
                bonus = 32
            else:
                bonus = 40
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

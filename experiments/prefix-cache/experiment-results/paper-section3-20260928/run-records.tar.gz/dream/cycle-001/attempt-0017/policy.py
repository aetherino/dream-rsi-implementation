class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Measured evidence through id 15 is authoritative:
        #   id 0 and strict-LRU-tie variants (2,3,5,6): 0.0
        #   id 1 (unbounded frequency/recency multiplier): -1.34 (catastrophic)
        #   id 7/8 (bounded depth bonus 8/16): +0.0006054 (80 tokens saved)
        #   id 9 (depth bonus plus hit tiers, cap 32): +0.0003632 (frequency hurts)
        #   id 10/11 (8/16/24): +0.0021794 (288 tokens saved)
        #   id 12/13 (8/16/24/32): +0.0055697 (736 tokens saved)
        #   id 14 (8/16/24/40, cap 40): +0.0072648 (960 tokens saved)
        #   id 15 (8/16/24/32/40, graduated, cap 40): +0.0090810
        #                                            (1200 tokens saved)
        # The measured series is monotonically improving as the graduated
        # depth schedule deepens and extends: 8/16 -> 80, 8/16/24 -> 288,
        # 8/16/24/32 -> 736, 8/16/24/32/40 -> 1200 saved suite tokens.
        #
        # Revised hypothesis (v6): retain the verified best shape exactly (8
        # for depth 1, 16 for depth 2, 24 for depth 3, 32 for depth 4, 40 for
        # depth 5) and explore the next small, monotonic extension in the same
        # confirmed direction: add one more graduated tier, 48 for depth>=6,
        # still hard-capped at 48 virtual-time units so any block more than 48
        # time units older is evicted first regardless of depth. This preserves
        # the near-LRU property that separates every measured positive result
        # from the id-1 catastrophe, while slightly strengthening the
        # structural tail-first effect: a deep leaf is a true chain tail whose
        # eviction frees a block and exposes its next ancestor as eligible
        # later, whereas a shallow leaf anchors a longer resident chain whose
        # recomputation is expensive. The progression 8 -> 16 -> 24 -> 32 ->
        # 40 -> 48 is the smallest monotonic continuation of the validated
        # 8/16/24/32/40 schedule; if measurement regresses, restoring exactly
        # id 15's parameterization (8/16/24/32/40) is the validated fallback at
        # +0.0090810, and exact LRU remains the measured 0.0 safety net.
        #
        # Task flags (task_chat, task_qa, task_unknown, turn_index) remain
        # excluded: the prompt states task category does not guarantee future
        # reuse and no completed measurement supports task-aware weighting.
        # block_id is used only as a deterministic identity tie-break, never as
        # a predictive feature.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            elif depth == 3:
                bonus = 24
            elif depth == 4:
                bonus = 32
            elif depth == 5:
                bonus = 40
            else:
                bonus = 48
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

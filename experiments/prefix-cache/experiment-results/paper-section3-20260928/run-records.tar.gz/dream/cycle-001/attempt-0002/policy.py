class CachePolicy:
    def __init__(self):
        self.last = {}
        self.start = {}
        self.hits = {}
        self.depth = {}
        self.evictions = {}
        self.inserted_at = {}

    def observe_insert(self, entry):
        bid = entry.block_id
        self.last[bid] = entry.last_access
        self.start[bid] = entry.inserted_at
        self.inserted_at[bid] = entry.inserted_at
        self.depth[bid] = entry.depth
        self.hits.setdefault(bid, 0)

    def observe_hit(self, entry):
        bid = entry.block_id
        self.last[bid] = entry.last_access
        self.start.setdefault(bid, entry.inserted_at)
        self.inserted_at.setdefault(bid, entry.inserted_at)
        self.depth[bid] = entry.depth
        self.hits[bid] = self.hits.get(bid, 0) + 1

    def observe_evict(self, entry):
        bid = entry.block_id
        self.evictions[bid] = self.evictions.get(bid, 0) + 1

    def choose(self, eligible, now):
        # Measured feedback: the frequency/recency multiplicative score produced
        # a suite-wide score of -1.34 versus exact LRU at 0.0, so that hypothesis
        # is rejected.  The tested policy was dominated by LRU on chat-heavy,
        # balanced and shift workloads and only won on some qa-heavy-00 cases.
        #
        # Revised hypothesis: retain blocks that are cheap to keep and likely to
        # be reused along a chain, and evict true chain tails first.  A leaf with
        # no resident descendants costs one block but can expose its parent
        # after eviction.  The primary ranking is the deterministic LRU order
        # (last_access, access_order), which is the strongest verified baseline.
        # Small adjustments only reorder near-ties and never override a
        # substantially older last_access.
        #
        # key = (effective_last_access, access_order, insertion_order, block_id)
        # where effective_last_access is the observed last access shifted by a
        # bounded penalty based on observed reuse depth.
        best = None
        best_key = None
        for entry in eligible:
            bid = entry.block_id
            last = self.last.get(bid, entry.last_access)
            depth = self.depth.get(bid, entry.depth)
            hits = self.hits.get(bid, 0)
            # Deeper blocks sit closer to the prefix end and are cheap to
            # rebuild; shallow blocks anchor long chains and are expensive to
            # lose, so protect shallow blocks via a small last-access boost.
            # Only a tiny amount is used so near-LRU behaviour dominates.
            boost = 0
            if depth <= 4:
                boost += 2
            if hits > 0:
                boost += 1
            effective = last - boost
            key = (effective, entry.access_order, entry.insertion_order, bid)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

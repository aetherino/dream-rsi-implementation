class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Measured evidence summary: exact LRU and all strict tie-break
        # variants score 0.0. The unbounded frequency/recency multiplier (id 1)
        # scored -1.34 and is rejected. The bounded depth bonus (id 7: bonus 8
        # for depth>=1, 16 for depth>=2) is the best measured positive at
        # +0.000605 (132,064 vs LRU 132,144 suite tokens). The hit-augmented
        # variant (id 9: extra bonus for hits) scored lower at +0.00036, so
        # observed frequency should not add to the bonus. The selected parent
        # (id 8) is functionally identical to id 7 and confirms the same
        # +0.000605 result.
        #
        # Revised hypothesis (v3): retain the verified winning bonus shape
        # (8 for depth>=1, 16 for depth>=2) exactly, and sharpen the tail-first
        # effect by slightly increasing the bonus for deeper leaves (depth>=3)
        # up to a hard cap of 24 virtual-time units. Rationale: a deep leaf is a
        # true chain tail -- evicting it frees a block and exposes its next
        # ancestor as eligible later -- while a shallow leaf anchors a longer
        # resident chain whose recomputation costs many tokens if reused. The
        # cap keeps the policy near-LRU: a block more than 24 virtual-time
        # units older is still evicted first, avoiding the id-1 failure mode
        # where large deviations from recency destroyed reuse. The id-9 result
        # shows that adding frequency terms reduces the gain, so frequency is
        # not used in the bonus. This is a small, strictly bounded extrapolation
        # of the only measured positive region and may regress; if so, the
        # exact id 7 parameterization (8/16) is the measured fallback.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            else:
                bonus = 24
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Complete measured feedback across all completed histories is authoritative:
        #   id 0 and strict-LRU-tie variants (2,3,5,6): 0.0
        #   id 1 (unbounded frequency/recency multiplier): -1.34 (catastrophic)
        #   bounded graduated depth-bonus family (the only positive region):
        #     8/16 -> +0.0006054 (80 tokens saved)
        #     8/16/24 -> +0.0021794 (288)
        #     8/16/24/32 -> +0.0055697 (736)
        #     8/16/24/32/40 -> +0.0090810 (1200)
        #     .../40/48 -> +0.0140453 (1856)
        #     .../48/56 -> +0.0202204 (2672)
        #     .../56/64 -> +0.0260322 (3440)
        #     .../64/72 -> +0.0311176 (4112)
        #     .../72/80 -> +0.0342656 (4528)
        #     .../80/88 -> +0.0374137 (4944)
        #     .../88/96 -> +0.0410461 (5424)
        #     .../96/104 -> +0.0433466 (5728)
        #     .../104/112 -> +0.0463737 (6128)
        #     .../112/120 (cap 120) -> +0.0475845 (6288 saved) -- MEASURED
        #       OPTIMUM (125,856 vs LRU 132,144), confirmed repeatedly.
        # Every probe past 120 FAILED and is preserved as falsification:
        #   tier 128 (ids 14/15 in both histories): +0.0408040 (regression)
        #   tier 136/144 (id 3 history 1): +0.0340235 (regression)
        #   tier 124 (id 4 history 1): +0.0431045 (regression)
        #   rollback depth>=16 to 112 (id 16 history 2): +0.0462526
        #   wrap depth>=24 to 0 (id 19 history 2): -0.0094442 (failure)
        #   hit-tier bonus variant (id 9 early history): +0.0003632 (worse)
        # Repeated identical measurements of the 8/16/.../120 schedule all give
        # exactly +0.0475845, confirming determinism and the peak.
        # This proposal therefore restores exactly the measured-best
        # parameterization: bonus 8*depth for depth 1..14 and 120 for depth>=15,
        # hard-capped at 120 virtual-time units. Near-LRU property preserved:
        # a block more than 120 time units older is evicted first regardless of
        # depth. Frequency stays excluded per the hit-tier regression. Task
        # flags unused (category does not guarantee future reuse). block_id is
        # only a deterministic identity tie-break.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            elif depth == 3:
                bonus = 24
            elif depth == 4:
                bonus = 32
            elif depth == 5:
                bonus = 40
            elif depth == 6:
                bonus = 48
            elif depth == 7:
                bonus = 56
            elif depth == 8:
                bonus = 64
            elif depth == 9:
                bonus = 72
            elif depth == 10:
                bonus = 80
            elif depth == 11:
                bonus = 88
            elif depth == 12:
                bonus = 96
            elif depth == 13:
                bonus = 104
            elif depth == 14:
                bonus = 112
            else:
                bonus = 120
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

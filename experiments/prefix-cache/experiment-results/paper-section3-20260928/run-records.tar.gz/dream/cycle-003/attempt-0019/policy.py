class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Complete measured feedback across all completed histories is
        # authoritative and fully settles the search. Exact LRU (id 0) and all
        # strict tie-break variants score exactly 0.0. The unbounded
        # frequency/recency multiplier (id 1) scored -1.34 (suite extra 309,856
        # vs 132,144), with catastrophic losses on chat-heavy-00-cap2048
        # (60,416) and shift-00-cap2048 (52,800); it is decisively rejected.
        # The bounded graduated depth-bonus family is the sole measured-positive
        # region and improved monotonically up to the schedule 8/16/24/32/40/
        # 48/56/64/72/80/88/96/104/112/120 with cap 120: 80, 288, 736, 1200,
        # 1856, 2672, 3440, 4112, 4528, 4944, 5424, 5728, 6128, 6288 suite
        # tokens saved (i.e. +0.0475845, 125,856 vs LRU 132,144), confirmed by
        # identical repeated measurements. Every probe past 120 FAILED:
        #   tier 128 (ids 14/15/17 both histories): +0.0408040
        #   tier 124 (id 4): +0.0431045
        #   tier 136/144 (id 3): +0.0340235
        #   rollback depth>=16 to 112 (id 16): +0.0462526
        #   wrap depth>=24 to 0 (id 19): -0.0094442 (failure)
        #   hit-tier bonus (id 9 early history): +0.0003632 (worse)
        # All of these sit below the validated +0.0475845, so the deepest-tail
        # bonus of 120 for depth>=15 is the empirical peak of the family and
        # the monotone-extension hypothesis is fully falsified past 120.
        # The selected parent is exactly this measured-best parameterization and
        # re-measured +0.0475845, matching the best-ever record. This proposal
        # preserves exactly that validated schedule (bonus 8*depth for depth
        # 1..14, 120 for depth>=15, hard-capped at 120 virtual-time units).
        # Near-LRU property preserved: a block more than 120 virtual-time units
        # older is evicted first regardless of depth, shared by every measured
        # positive result and absent from the id-1 catastrophe. Frequency/hit
        # terms stay excluded per the id-9 regression (+0.0003632 vs +0.0006054).
        # Task flags remain unused because the prompt states task category does
        # not guarantee future reuse and no measurement supports task-aware
        # weighting; block_id is used only as a deterministic identity
        # tie-break, never as a predictive feature. Structural rationale: a
        # deep leaf is a true chain tail whose eviction frees a block and
        # exposes its next ancestor as eligible later, whereas a shallow leaf
        # anchors a longer resident chain whose recomputation is expensive.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            elif depth == 3:
                bonus = 24
            elif depth == 4:
                bonus = 32
            elif depth == 5:
                bonus = 40
            elif depth == 6:
                bonus = 48
            elif depth == 7:
                bonus = 56
            elif depth == 8:
                bonus = 64
            elif depth == 9:
                bonus = 72
            elif depth == 10:
                bonus = 80
            elif depth == 11:
                bonus = 88
            elif depth == 12:
                bonus = 96
            elif depth == 13:
                bonus = 104
            elif depth == 14:
                bonus = 112
            else:
                bonus = 120
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

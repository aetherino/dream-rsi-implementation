class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Complete measured feedback is authoritative:
        #   id 0 and strict-LRU-tie variants (2,3,5,6): 0.0
        #   id 1 (unbounded frequency/recency multiplier): -1.34 (catastrophic)
        #   id 7/8 (bounded depth bonus 8/16): +0.0006054 (80 tokens saved)
        #   id 9 (depth bonus plus hit tiers, cap 32): +0.0003632 (worse)
        #   id 10/11 (8/16/24): +0.0021794 (288 tokens saved)
        #   id 12/13 (8/16/24/32): +0.0055697 (736 tokens saved)
        #   id 14 (8/16/24/40 for depth>=4, cap 40): +0.0072648 (960 saved)
        #   id 15 (8/16/24/32/40, cap 40): +0.0090810 (1200 saved)
        #   id 16/17 (8/16/24/32/40/48, cap 48): +0.0140453 (1856 saved)
        #   id 18/19 (8/16/24/32/40/48/56, cap 56): +0.0202204 (2672 saved)
        #   id 20/21 (8/16/24/32/40/48/56/64, cap 64): +0.0260322 (3440)
        #   id 22 (8/16/24/32/40/48/56/64/72, cap 72): +0.0311176 (4112)
        #   id 23/24 (8/16/24/32/40/48/56/64/72/80, cap 80):
        #        +0.0342656 (4528 saved)
        #   id 4/5 (8/16/24/32/40/48/56/64/72/80/88, cap 88):
        #        +0.0374137 (4944 saved)
        #   id 6/7 (8/16/24/32/40/48/56/64/72/80/88/96, cap 96):
        #        +0.0410461 (5424 saved)
        #   id 8/9 (8/16/24/32/40/48/56/64/72/80/88/96/104, cap 104):
        #        +0.0433466 (5728 saved)
        #   id 10/11 (8/16/.../104/112, cap 112): +0.0463737 (6128 saved)
        #   id 12/13 (8/16/.../112/120, cap 120): +0.0475845 (6288 saved)
        #   id 14/15 (8/16/.../120/128, cap 128): +0.0408040 (5392 saved)
        #        -- REGRESSION: extending the schedule past 120 hurt.
        #
        # Measured fact: the monotone tier-extension series improved up to
        # 8/16/.../120 (cap 120, +0.0475845) and then regressed at
        # 8/16/.../128 (cap 128, +0.0408040).  Adding another tier for
        # depth>=16 hurt, which falsifies the naive 'keep adding tiers'
        # extrapolation.  But note that 128 differs from 120 only for
        # depth>=16: when depth<=15 both policies use bonus 8*depth.  The
        # schedule for depths 1..15 is identical in both, and depth>=16 got
        # 128 instead of 120.  The loss came specifically from the depth>=16
        # bonus increasing from 120 to 128.  This suggests depth>=16 blocks
        # are a small population whose bonus should DECREASE, not increase.
        #
        # Revised hypothesis: keep the validated graduated schedule
        # 8/16/24/.../120 for depths 1..15 exactly as in id 12/13 (the
        # measured best at +0.0475845), and set the depth>=16 bonus BACK to
        # 112 (i.e. the same as depth 14), hard-capped at 112.  This is a
        # mild rollback for the deepest tail (112 instead of 120), which
        # follows the measured evidence that raising depth>=16 from 120 to
        # 128 hurt.  The schedule is 8/16/24/32/40/48/56/64/72/80/88/96/104/
        # 112/120/112 for depth 1..16+, with cap 120 on the key.  The
        # near-LRU property is preserved and depth>=16 tail preference is
        # tempered relative to the measured-best parent.  Frequency stays
        # excluded per id 9.  Task flags remain unused (category does not
        # guarantee reuse).  block_id is only a deterministic identity
        # tie-break.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            elif depth == 3:
                bonus = 24
            elif depth == 4:
                bonus = 32
            elif depth == 5:
                bonus = 40
            elif depth == 6:
                bonus = 48
            elif depth == 7:
                bonus = 56
            elif depth == 8:
                bonus = 64
            elif depth == 9:
                bonus = 72
            elif depth == 10:
                bonus = 80
            elif depth == 11:
                bonus = 88
            elif depth == 12:
                bonus = 96
            elif depth == 13:
                bonus = 104
            elif depth == 14:
                bonus = 112
            elif depth == 15:
                bonus = 120
            else:
                bonus = 112
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Complete measured feedback is authoritative:
        #   id 0 and strict-LRU-tie variants (2,3,5,6): 0.0
        #   id 1 (unbounded frequency/recency multiplier): -1.34 (catastrophic)
        #   id 7/8 (bounded depth bonus 8/16): +0.0006054 (80 tokens saved)
        #   id 9 (depth bonus plus hit tiers, cap 32): +0.0003632 (worse)
        #   id 10/11 (8/16/24): +0.0021794 (288 tokens saved)
        #   id 12/13 (8/16/24/32): +0.0055697 (736 tokens saved)
        #   id 14 (8/16/24/40 for depth>=4, cap 40): +0.0072648 (960 saved)
        #   id 15 (8/16/24/32/40, cap 40): +0.0090810 (1200 saved)
        #   id 16/17 (8/16/24/32/40/48, cap 48): +0.0140453 (1856 saved)
        #   id 18/19 (8/16/24/32/40/48/56, cap 56): +0.0202204 (2672 saved)
        #   id 20/21 (8/16/24/32/40/48/56/64, cap 64): +0.0260322 (3440)
        #   id 22 (8/16/24/32/40/48/56/64/72, cap 72): +0.0311176 (4112)
        #   id 23/24 (8/16/24/32/40/48/56/64/72/80, cap 80):
        #        +0.0342656 (4528 saved)
        #   id 4/5 (8/16/24/32/40/48/56/64/72/80/88, cap 88):
        #        +0.0374137 (4944 saved)
        #   id 6/7 (8/16/24/32/40/48/56/64/72/80/88/96, cap 96):
        #        +0.0410461 (5424 saved)
        #   id 8/9 (8/16/24/32/40/48/56/64/72/80/88/96/104, cap 104):
        #        +0.0433466 (5728 saved)
        #   id 10/11 (8/16/.../104/112, cap 112): +0.0463737 (6128 saved)
        #   id 12/13 (8/16/.../112/120, cap 120): +0.0475845 (6288 saved)
        #        -- the measured best.
        # The depth-bonus series is monotonically improving as the graduated
        # schedule grows finer and the cap grows: 8/16 -> 80, 8/16/24 -> 288,
        # 8/16/24/32 -> 736, 8/16/24/32/40 -> 1200,
        # 8/16/24/32/40/48 -> 1856, 8/16/24/32/40/48/56 -> 2672,
        # 8/16/24/32/40/48/56/64 -> 3440, .../64/72 -> 4112,
        # .../72/80 -> 4528, .../80/88 -> 4944, .../88/96 -> 5424,
        # .../96/104 -> 5728, .../104/112 -> 6128, .../112/120 -> 6288.
        #
        # Revised hypothesis (v16): continue that validated monotone direction
        # with the smallest remaining step: add one more graduated tier, 128 for
        # depth>=16, still hard-capped at 128 virtual-time units so any block
        # more than 128 time units older is evicted first regardless of depth.
        # This preserves the near-LRU property shared by every measured
        # positive result and absent from the id-1 catastrophe, while further
        # strengthening the structural tail-first effect. Id 9 keeps frequency
        # excluded from the key. Task flags remain unused (category does not
        # guarantee reuse). block_id is only a deterministic identity tie-break.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            elif depth == 3:
                bonus = 24
            elif depth == 4:
                bonus = 32
            elif depth == 5:
                bonus = 40
            elif depth == 6:
                bonus = 48
            elif depth == 7:
                bonus = 56
            elif depth == 8:
                bonus = 64
            elif depth == 9:
                bonus = 72
            elif depth == 10:
                bonus = 80
            elif depth == 11:
                bonus = 88
            elif depth == 12:
                bonus = 96
            elif depth == 13:
                bonus = 104
            elif depth == 14:
                bonus = 112
            elif depth == 15:
                bonus = 120
            else:
                bonus = 128
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id

class CachePolicy:
    def __init__(self):
        self.last = {}
        self.depth = {}
        self.hits = {}
        self.inserted = {}
        self.evictions = {}

    def observe_insert(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits.setdefault(b, 0)
        self.inserted[b] = entry.inserted_at

    def observe_hit(self, entry):
        b = entry.block_id
        self.last[b] = entry.last_access
        self.depth[b] = entry.depth
        self.hits[b] = self.hits.get(b, 0) + 1
        self.inserted.setdefault(b, entry.inserted_at)

    def observe_evict(self, entry):
        b = entry.block_id
        self.evictions[b] = self.evictions.get(b, 0) + 1
        self.last.pop(b, None)
        self.depth.pop(b, None)
        self.hits.pop(b, None)
        self.inserted.pop(b, None)

    def choose(self, eligible, now):
        # Complete measured feedback is authoritative:
        #   id 0 and strict-LRU-tie variants (2,3,5,6): 0.0
        #   id 1 (unbounded frequency/recency multiplier): -1.34 (catastrophic)
        #   id 7/8 (bounded depth bonus 8/16): +0.0006054 (80 tokens saved)
        #   id 9 (depth bonus plus hit tiers, cap 32): +0.0003632 (worse)
        #   id 10/11 (8/16/24): +0.0021794 (288 tokens saved)
        #   id 12/13 (8/16/24/32): +0.0055697 (736 tokens saved)
        #   id 14 (8/16/24/32/40): +0.0072648 (960 saved)
        #   id 15 (8/16/24/32/40/48): +0.0090810 (1200 saved)
        #   id 16/17 (.../48/56): +0.0140453 (1856 saved)
        #   id 18/19 (.../56/64): +0.0202204 (2672 saved)
        #   id 20/21 (.../64/72): +0.0260322 (3440 saved)
        #   id 22 (.../72/80): +0.0311176 (4112 saved)
        #   id 23/24 (.../80/88): +0.0342656 (4528 saved)
        #   id 4/5 (.../88/96): +0.0374137 (4944 saved)
        #   id 6/7 (.../96/104): +0.0410461 (5424 saved)
        #   id 8/9 (.../104/112): +0.0433466 (5728 saved)
        #   id 10/11 (.../112/120): +0.0463737 (6128 saved)
        #   id 12/13 (.../120/128): +0.0475845 (6288 saved) -- measured best.
        #   id 14/15 (.../128/136): +0.0408040 (5392 saved) -- REGRESSION.
        #   id 16 (.../128 for depth>=16, 112 for depth>=17): +0.0462526
        #   (6112 saved) -- rollback improved over 128/136 but lost vs 120.
        #
        # The measured optimum is the graduated schedule
        # 8/16/24/32/40/48/56/64/72/80/88/96/104/112/120 with cap 120.
        # Extensions past 120 regressed (128 and 136 both lost suite tokens),
        # and a rollback to 112 for the deepest tier also lost.  The deepest
        # tail bonus is therefore settled at 120 for depth>=15.  To explore a
        # different, untested direction without touching the validated
        # schedule, this candidate wraps the deepest tail back to the cap:
        # bonus = 120 for depth 15..23 and bonus = 0 for depth>=24, i.e. the
        # bonus schedule is 8/16/24/.../120/(0) with the deepest zone treated
        # as recency-pure.  This hypothesis is that very deep tails (depth>=24)
        # are extreme outliers whose extra tail preference beyond 120 is
        # counterproductive (consistent with the 128/136 regressions), while
        # the validated 8..120 tiers for depth<=23 are preserved exactly.
        # Frequency remains excluded per the id-9 regression.  Task flags remain
        # unused because category does not guarantee future reuse.  block_id is
        # only a deterministic identity tie-break.
        best = None
        best_key = None
        for entry in eligible:
            b = entry.block_id
            last = self.last.get(b, entry.last_access)
            depth = self.depth.get(b, entry.depth)
            if depth <= 0:
                bonus = 0
            elif depth >= 24:
                bonus = 0
            elif depth == 1:
                bonus = 8
            elif depth == 2:
                bonus = 16
            elif depth == 3:
                bonus = 24
            elif depth == 4:
                bonus = 32
            elif depth == 5:
                bonus = 40
            elif depth == 6:
                bonus = 48
            elif depth == 7:
                bonus = 56
            elif depth == 8:
                bonus = 64
            elif depth == 9:
                bonus = 72
            elif depth == 10:
                bonus = 80
            elif depth == 11:
                bonus = 88
            elif depth == 12:
                bonus = 96
            elif depth == 13:
                bonus = 104
            elif depth == 14:
                bonus = 112
            elif depth == 15:
                bonus = 120
            elif depth == 16:
                bonus = 120
            elif depth == 17:
                bonus = 120
            elif depth == 18:
                bonus = 120
            elif depth == 19:
                bonus = 120
            elif depth == 20:
                bonus = 120
            elif depth == 21:
                bonus = 120
            elif depth == 22:
                bonus = 120
            elif depth == 23:
                bonus = 120
            else:
                bonus = 0
            key = (last - bonus, entry.access_order, entry.insertion_order, b)
            if best_key is None or key < best_key:
                best_key = key
                best = entry
        return best.block_id
